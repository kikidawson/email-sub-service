import boto3

def handler(event: dict) -> dict:
    return "invoked"
